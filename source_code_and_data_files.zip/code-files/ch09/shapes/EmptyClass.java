// This class doesn't compile because it doesn't 
// actually implement the Shape interface.
public class EmptyClass implements Shape {

}
