// A class to represent secretaries.
public class Secretary extends Employee {
    public void takeDictation() {
        System.out.println("I know how to take dictation.");
    }
}
