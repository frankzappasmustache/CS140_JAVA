public class Hello3 {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
        System.out.println();
        System.out.println("This program produces four");
        System.out.println("lines of output.");
    }
}
