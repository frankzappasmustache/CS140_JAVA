public class Infinite {
    public static void main(String[] args) {
        oops();
    }
    
    public static void oops() {
        System.out.println("Make it stop!");
        oops();
    }
}
