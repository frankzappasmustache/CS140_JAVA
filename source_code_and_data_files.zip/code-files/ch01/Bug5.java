public class Bug5 {
    public static main(String[] args) {
        System.out.println("Hello, world!");
    }
}
