public class Bug2 {
    public static void main(String[] args) {
        system.out.println("Hello, world!");
    }
}
