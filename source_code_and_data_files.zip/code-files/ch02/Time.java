public class Time {
    public static void main(String[] args) {
        int hours = 365 * 24;
        int minutes = hours * 60;
        int seconds = minutes * 60;
        System.out.println("Hours in a year   = " + hours);
        System.out.println("Minutes in a year = " + minutes);
        System.out.println("Seconds in a year = " + seconds);
    }
}
