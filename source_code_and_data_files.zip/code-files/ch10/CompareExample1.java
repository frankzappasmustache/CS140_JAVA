public class CompareExample1 {
    public static void main(String[] args) {
	Integer x = 7;
	Integer y = 42;
	Integer z = 7;
	System.out.println(x.compareTo(y));
	System.out.println(x.compareTo(z));
	System.out.println(y.compareTo(x));
    }
}
