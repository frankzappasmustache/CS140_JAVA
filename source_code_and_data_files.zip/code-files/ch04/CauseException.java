public class CauseException {
    public static void main(String[] args) {
        int x = 1 / 0;
        System.out.println(x);
    }
}
