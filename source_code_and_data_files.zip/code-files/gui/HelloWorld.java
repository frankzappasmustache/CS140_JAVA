// A graphical equivalent of the classic "Hello world" program.

import javax.swing.*;   // for GUI components

public class HelloWorld {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hello, world!");
    }
}
